// Visit Counter with Local Storage

let visitCounter = Number(localStorage.getItem('visits')) || 0;
visitCounter++;
localStorage.setItem('visits', visitCounter);
document.querySelector('.visitCountP').textContent = `Visit Counter: ${visitCounter}`;

//Change theme

const themeChangeBut = document.querySelector('.themeChanger');
const StyleSh = document.getElementById('styles');

//remembering the theme

let themeWas = localStorage.getItem('theme');
if (themeWas === null) {
    StyleSh.setAttribute('href', 'styleshit.css');
    localStorage.setItem('theme', 'styleshit.css');
} else {
    StyleSh.setAttribute('href', themeWas);
}

//click the button ThemeChanger
themeChangeBut.addEventListener('click', () => {
    const styleHref = StyleSh.getAttribute('href');
    if (styleHref === 'styleshit.css') {
        StyleSh.setAttribute('href', 'styleshitDark.css');
        localStorage.setItem('theme', 'styleshitDark.css');
    } else {
        StyleSh.setAttribute('href', 'styleshit.css');
        localStorage.setItem('theme', 'styleshit.css');
    };
});

//ToDo List

const AddBut = document.getElementById('ListItemAddButton');
const UnorList = document.querySelector('.ToDoListListList');
let TaskToAdd = document.querySelector('.ToDoListControlAdd');
let CleanET = document.querySelector('.ToDoListControlClean');
AddBut.addEventListener('click', () => {
    if (TaskToAdd.value !== '') {
        let NewLI = document.createElement('li');
        NewLI.className = 'ToDoListListItem';
        NewLI.textContent = TaskToAdd.value.trim();
        UnorList.appendChild(NewLI);
        TaskToAdd.value = '';
    }
});
UnorList.addEventListener('click', (e) => {
    if (e.target && e.target.tagName === 'LI') {
        e.target.classList.toggle('done');
    }
});
UnorList.addEventListener('dblclick', (e) => {
    if (e.target && e.target.tagName === 'LI') {
        e.target.remove();
    }
});
CleanET.addEventListener('click', () => {
    let choice1 = confirm('Are you sure?');
    if (choice1) {
        const allTasks = UnorList.querySelectorAll('li');
        allTasks.forEach(task => task.remove());
    }
});

//Form
const nameField = document.querySelector('.nameField');
const subBut = document.getElementById('submitBut');
subBut.addEventListener('click', (e) => {
    if (nameField.value.trim() === '') {
        alert('Fill the field');
        e.preventDefault();
    }
});