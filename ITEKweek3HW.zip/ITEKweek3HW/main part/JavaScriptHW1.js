// Проверка возраста
function ageCheck(age) {
    let result = (age>=18)
        ?'Adult'
        :'Kid';
    return result
}
console.log(ageCheck(20))

// Массив студентов
let students = [
    {name: 'Kuro', lastName: 'Burakuoku', age: 16, class: 11},
    {name: 'Bashi', lastName: 'Havaito', age: 18, class: 12},
    {name: 'Shigemi', lastName: 'Nagai', age: 18, class: 12},
    {name: 'Toriniki', lastName: 'Ongaku', age: 17, class: 13},
    {name: 'Nezumi', lastName: 'Kodokuno', age: 17, class: 11},
    {name: 'Aoi', lastName: 'Raito', age: 17, class: 11}
    ];

console.log(students)

//Перебор массива
for (let i = 0; i<students.length; ++i){
    console.log(students[i]);
}

//Проверка оценки
function gradeCheck(score, maxScore = 30) {
    let percents = score*100/maxScore;
    let result;
    if (percents >100)
    {
        result = 'A+';
    }
    else if (percents >= 85)
    {
        result = 'A';
    }
    else if (percents >=65)
    {
        result = 'B';
    }
    else
    {
        result = 'C';
    }
    console.log(`Your grade is ${result}!`)
}
gradeCheck(50)